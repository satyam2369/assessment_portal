package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssessmentPortal2Application {

	public static void main(String[] args) {
		SpringApplication.run(AssessmentPortal2Application.class, args);
	}
}
