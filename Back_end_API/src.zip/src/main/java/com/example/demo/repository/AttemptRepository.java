package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.demo.entity.Attempt_test;

public interface AttemptRepository extends JpaRepository<Attempt_test, Long>{

}
